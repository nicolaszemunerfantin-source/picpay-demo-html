package com.zapia.skyblock;

import com.zapia.picpayvisual.R;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.text.TextUtils;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/** Receives demo-only FCM messages. It never represents a real Pix or payment. */
public final class SimulationMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL = "picpay_demo_remote_simulations";
    private static final AtomicInteger IDS = new AtomicInteger(8100);

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        try {
            EncryptedSharedPreferences.create(this, "picpay_simulation_pairing",
                    new MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
                    .edit().putString("fcm_token", token).apply();
        } catch (GeneralSecurityException | IOException ignored) { }
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        Map<String, String> data = message.getData();
        // Deliberately reject any message not explicitly marked as a simulation.
        if (!"true".equalsIgnoreCase(data.get("simulation"))) return;
        if (!hasApprovedPairing(data.get("senderId"))) return;
        String body = data.get("body");
        if (TextUtils.isEmpty(body)) body = "Você recebeu uma mensagem demonstrativa.";
        body = body.substring(0, Math.min(body.length(), 180));
        showNotification(body);
    }

    private boolean hasApprovedPairing(String senderId) {
        try {
            return !TextUtils.isEmpty(senderId)
                    && EncryptedSharedPreferences.create(this, "picpay_simulation_pairing",
                    new MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
                    .getBoolean("pair_approved_" + senderId, false);
        } catch (GeneralSecurityException | IOException ignored) { return false; }
    }

    private void showNotification(String body) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL,
                    "PicPay — simulações entre aparelhos", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Mensagens demonstrativas. Nenhum dinheiro é movimentado.");
            manager.createNotificationChannel(channel);
        }
        Notification notification = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("SIMULAÇÃO · PicPay Visual")
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body
                        + "\nSIMULAÇÃO — nenhum dinheiro foi movimentado; nenhum Pix real foi enviado."))
                .setSubText("SIMULAÇÃO · Nenhum Pix real enviado")
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true).build();
        try { NotificationManagerCompat.from(this).notify(IDS.incrementAndGet(), notification); }
        catch (SecurityException ignored) { }
    }
}
