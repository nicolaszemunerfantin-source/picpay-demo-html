# Protótipo visual Android — demonstração

App Android de teste que abre o protótipo local em WebView. O leitor QR usa a câmera do aparelho após as permissões do Android e do WebView. O fluxo permanece fictício: não se conecta a banco e não envia Pix.

Compilação: GitHub Actions → Build demo APK → Run workflow. O APK de teste é publicado como artifact do job.
