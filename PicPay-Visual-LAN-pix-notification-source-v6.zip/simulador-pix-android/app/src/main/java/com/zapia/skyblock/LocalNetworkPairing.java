package com.zapia.skyblock;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

final class LocalNetworkPairing {
    interface Decision { void decide(boolean accepted); }
    interface Listener { void onEvent(String json); void onIncoming(String model, Decision decision); void onPix(String amount, String recipient); }
    private static final String TYPE="_picpaydemo._tcp.";
    private final Context context; private final Listener listener; private final NsdManager nsd;
    private final Handler main=new Handler(Looper.getMainLooper()); private final ExecutorService io=Executors.newCachedThreadPool();
    private final String id=UUID.randomUUID().toString().replace("-","").substring(0,12);
    private final String model=android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL;
    private final Map<String,NsdServiceInfo> peers=new HashMap<>();
    private volatile boolean active=false; private volatile PeerSession connected; private ServerSocket server; private NsdManager.RegistrationListener registration; private NsdManager.DiscoveryListener discovery;
    LocalNetworkPairing(Context c,Listener l){context=c.getApplicationContext();listener=l;nsd=(NsdManager)context.getSystemService(Context.NSD_SERVICE);}
    synchronized boolean start(){
        if(active){emitDevices();return true;} if(nsd==null)return false;
        try{server=new ServerSocket(0);active=true;final int port=server.getLocalPort();io.execute(this::acceptLoop);
            NsdServiceInfo info=new NsdServiceInfo();info.setServiceName("PicPayDemo-"+id);info.setServiceType(TYPE);info.setPort(port);info.setAttribute("device",id);info.setAttribute("model",safe(model));
            registration=new NsdManager.RegistrationListener(){public void onServiceRegistered(NsdServiceInfo i){} public void onRegistrationFailed(NsdServiceInfo i,int e){error("Não foi possível anunciar este celular na rede Wi-Fi.");} public void onServiceUnregistered(NsdServiceInfo i){} public void onUnregistrationFailed(NsdServiceInfo i,int e){}};
            nsd.registerService(info,NsdManager.PROTOCOL_DNS_SD,registration);
            discovery=new NsdManager.DiscoveryListener(){public void onDiscoveryStarted(String t){emit("searching",null);} public void onServiceFound(NsdServiceInfo si){if(!TYPE.equals(si.getServiceType())||si.getServiceName().contains(id))return;try{nsd.resolveService(si,new NsdManager.ResolveListener(){public void onResolveFailed(NsdServiceInfo x,int e){} public void onServiceResolved(NsdServiceInfo r){String rid=attr(r,"device",r.getServiceName());if(id.equals(rid))return;synchronized(peers){peers.put(rid,r);}emitDevices();}});}catch(Exception ignored){}} public void onServiceLost(NsdServiceInfo si){synchronized(peers){peers.values().removeIf(x->x.getServiceName().equals(si.getServiceName()));}emitDevices();} public void onDiscoveryStopped(String t){} public void onStartDiscoveryFailed(String t,int e){error("A rede Wi-Fi não permitiu buscar aparelhos. Confira se os dois celulares estão na mesma rede.");stop();} public void onStopDiscoveryFailed(String t,int e){}};
            nsd.discoverServices(TYPE,NsdManager.PROTOCOL_DNS_SD,discovery);return true;
        }catch(Exception e){stop();return false;}
    }
    synchronized void stop(){active=false;PeerSession old=connected;connected=null;if(old!=null)try{old.socket.close();}catch(Exception ignored){};try{if(discovery!=null)nsd.stopServiceDiscovery(discovery);}catch(Exception ignored){}try{if(registration!=null)nsd.unregisterService(registration);}catch(Exception ignored){}try{if(server!=null)server.close();}catch(Exception ignored){}discovery=null;registration=null;server=null;synchronized(peers){peers.clear();}emit("stopped",null);}
    boolean connect(String peer){
        NsdServiceInfo p; synchronized(peers){p=peers.get(peer);}
        if(!active||p==null||p.getHost()==null)return false;
        io.execute(()->{try{
            Socket socket=new Socket(p.getHost(),p.getPort());
            BufferedWriter w=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8));
            BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));
            w.write("PAIR_REQ\n"+enc(id)+"\n"+enc(model)+"\n");w.flush();
            if(!"ACCEPT".equals(r.readLine())){socket.close();error("O outro aparelho recusou ou não respondeu ao pedido.");return;}
            connected=new PeerSession(socket,r,w);emit("paired",null);connected.readLoop();
        }catch(Exception e){error("Não foi possível conectar. Confira se os celulares continuam na mesma rede Wi-Fi e com a busca aberta.");}});
        return true;
    }
    boolean sendPix(String amount,String recipient){PeerSession p=connected;return p!=null&&p.sendPix(amount,recipient);}
    private void acceptLoop(){while(active&&server!=null){try{Socket s=server.accept();io.execute(()->handle(s));}catch(Exception e){if(active)error("A conexão local foi interrompida.");return;}}}
    private void handle(Socket s){
        try{
            s.setSoTimeout(30000);
            BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));
            BufferedWriter w=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8));
            if(!"PAIR_REQ".equals(r.readLine())){s.close();return;}
            String remoteId=dec(r.readLine()),remoteModel=dec(r.readLine());
            if(remoteId.length()>64||remoteModel.length()>100){s.close();return;}
            main.post(()->listener.onIncoming(remoteModel,ok->{
                try{
                    w.write(ok?"ACCEPT\n":"REJECT\n");w.flush();
                    if(ok){s.setSoTimeout(0);connected=new PeerSession(s,r,w);emit("paired",null);io.execute(()->connected.readLoop());}
                    else s.close();
                }catch(Exception ignored){try{s.close();}catch(Exception ignored2){}}
            }));
        }catch(Exception e){try{s.close();}catch(Exception ignored){}}
    }
    private final class PeerSession {
        private final Socket socket; private final BufferedReader reader; private final BufferedWriter writer; private volatile boolean open=true;
        PeerSession(Socket s,BufferedReader r,BufferedWriter w){socket=s;reader=r;writer=w;}
        synchronized boolean sendPix(String amount,String recipient){
            if(!open||socket.isClosed())return false;
            try{writer.write("PIX\n"+enc(amount==null?"":amount)+"\n"+enc(recipient==null?"":recipient)+"\n");writer.flush();return true;}
            catch(Exception e){open=false;return false;}
        }
        void readLoop(){
            try{String command;while(open&&(command=reader.readLine())!=null){
                if(!"PIX".equals(command))continue;
                String amount=dec(reader.readLine()),recipient=dec(reader.readLine());
                if(amount.length()>80||recipient.length()>120)continue;
                main.post(()->listener.onPix(amount,recipient));
            }}catch(Exception ignored){}finally{open=false;try{socket.close();}catch(Exception ignored){}if(connected==this){connected=null;emit("disconnected","A conexão com o outro aparelho foi encerrada.");}}
        }
    }
    private void emitDevices(){JSONArray a=new JSONArray();synchronized(peers){for(Map.Entry<String,NsdServiceInfo>x:peers.entrySet())try{a.put(new JSONObject().put("id",x.getKey()).put("model",attr(x.getValue(),"model","Celular Android")));}catch(Exception ignored){}}JSONObject o=new JSONObject();try{o.put("status","devices").put("devices",a);}catch(Exception ignored){}main.post(()->listener.onEvent(o.toString()));}
    private static String attr(NsdServiceInfo i,String key,String fallback){try{byte[] b=i.getAttributes().get(key);return b==null?fallback:new String(b,StandardCharsets.UTF_8);}catch(Exception e){return fallback;}}
    private void emit(String status,String msg){JSONObject o=new JSONObject();try{o.put("status",status);if(msg!=null)o.put("message",msg);}catch(Exception ignored){}main.post(()->listener.onEvent(o.toString()));}
    private void error(String msg){emit("error",msg);} private static String enc(String s){return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP|Base64.URL_SAFE);} private static String dec(String s){return new String(Base64.decode(s==null?"":s,Base64.NO_WRAP|Base64.URL_SAFE),StandardCharsets.UTF_8);} private static String safe(String s){String t=s==null?"Android":s.replaceAll("[^A-Za-z0-9 ._-]","");return t.substring(0,Math.min(60,t.length()));}
}
