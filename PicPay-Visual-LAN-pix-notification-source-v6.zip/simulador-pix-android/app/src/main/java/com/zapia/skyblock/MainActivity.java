package com.zapia.skyblock;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.net.wifi.WifiManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.graphics.drawable.Icon;
import android.app.NotificationManager;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.ClipData;
import android.content.pm.PackageManager;
import android.widget.Toast;
import android.webkit.ValueCallback;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.IOException;
import java.security.GeneralSecurityException;
import org.json.JSONObject;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String CHANNEL_ID = "picpay_demo_pix_v5";
    private static final int SMALL_ICON_ID = 0x7f010000;
    private static final int REQ_CAMERA = 4101;
    private static final int REQ_NOTIFICATIONS = 4102;
    private WebView webView;
    private LocalNetworkPairing localNetworkPairing;
    private WifiManager.MulticastLock multicastLock;
    private PermissionRequest pendingWebPermission;
    private String pendingPixAmount, pendingPixRecipient;
    private String pendingCustomTitle, pendingCustomMessage;
    private int pendingCustomCount, pendingCustomIntervalSeconds;
    private int customNotificationsRemaining;
    private String customNotificationTitle, customNotificationMessage;
    private int customNotificationIntervalSeconds;
    private final Handler notificationHandler = new Handler(Looper.getMainLooper());
    private Runnable customNotificationRunnable;
    private static int nextCustomNotificationId = 9000;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        applyImmersiveMode();
        createNotificationChannel();
        webView = new WebView(this);
        webView.setBackgroundColor(0xff19a287);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new ClipboardBridge(this), "NativeClipboard");
        webView.addJavascriptInterface(new ShareBridge(), "NativeShare");
        webView.addJavascriptInterface(new PixNotificationBridge(), "NativePixNotification");
        webView.addJavascriptInterface(new SimulationPairingBridge(), "NativeSimulationPairing");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    boolean asksCamera = false;
                    for (String resource : request.getResources()) if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) asksCamera = true;
                    if (!asksCamera) { request.deny(); return; }
                    if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) request.grant(request.getResources());
                    else { if (pendingWebPermission != null) pendingWebPermission.deny(); pendingWebPermission = request; requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA); }
                });
            }
        });
        setContentView(webView);
        localNetworkPairing = new LocalNetworkPairing(this, new LocalNetworkPairing.Listener() {
            @Override public void onEvent(String json) {
                if (json.contains("\"paired\"")) runOnUiThread(() -> requestNotificationPermissionIfNeeded());
                if (webView != null) webView.evaluateJavascript("window.onLanPairingEvent && window.onLanPairingEvent(" + JSONObject.quote(json) + ")", null);
            }
            @Override public void onIncoming(String peerModel, LocalNetworkPairing.Decision decision) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Pedido de conexão local")
                    .setMessage(peerModel + " quer se conectar ao seu PicPay Visual na mesma rede Wi-Fi. Aceitar apenas se você conhece essa pessoa.\n\nA conexão é só para demonstração; nenhum dinheiro será enviado.")
                    .setPositiveButton("Aceitar", (dialog, which) -> decision.decide(true))
                    .setNegativeButton("Recusar", (dialog, which) -> decision.decide(false))
                    .setOnCancelListener(dialog -> decision.decide(false)).show();
            }
            @Override public void onPix(String amount, String recipient) {
                runOnUiThread(() -> {
                    if (canPostNotifications()) postPixNotification(amount, recipient);
                    else pairingResult("notification_permission_required", "Pix demonstrativo recebido, mas a permissão de notificações está desligada neste celular.");
                });
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        boolean needsCamera = Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED;
        if (needsCamera) requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
    }

    private void applyImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4102);
        }
    }

    private boolean canPostNotifications() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "PicPay — Simulação", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Notificações de demonstração. Nenhum dinheiro é enviado.");
            channel.setShowBadge(true);
            channel.enableVibration(true);
            ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private void startCustomNotificationSequence(String title, String message, int count, int intervalSeconds) {
        cancelCustomNotificationSequence();
        customNotificationTitle = title;
        customNotificationMessage = message;
        customNotificationsRemaining = Math.max(1, Math.min(10, count));
        customNotificationIntervalSeconds = Math.max(2, Math.min(3600, intervalSeconds));
        if (!canPostNotifications()) {
            pendingCustomTitle = title;
            pendingCustomMessage = message;
            pendingCustomCount = customNotificationsRemaining;
            pendingCustomIntervalSeconds = customNotificationIntervalSeconds;
            requestNotificationPermissionIfNeeded();
            return;
        }
        postNextCustomNotification();
    }

    private void postNextCustomNotification() {
        if (customNotificationsRemaining <= 0 || !canPostNotifications()) return;
        postCustomNotification(customNotificationTitle, customNotificationMessage);
        customNotificationsRemaining--;
        if (customNotificationsRemaining > 0) {
            customNotificationRunnable = this::postNextCustomNotification;
            notificationHandler.postDelayed(customNotificationRunnable, customNotificationIntervalSeconds * 1000L);
        }
    }

    private void cancelCustomNotificationSequence() {
        if (customNotificationRunnable != null) notificationHandler.removeCallbacks(customNotificationRunnable);
        customNotificationRunnable = null;
        customNotificationsRemaining = 0;
    }

    private void postCustomNotification(String title, String message) {
        if (!canPostNotifications()) { requestNotificationPermissionIfNeeded(); return; }
        String safeTitle = title == null || title.trim().isEmpty() ? "PicPay" : title.trim().substring(0, Math.min(80, title.trim().length()));
        String safeMessage = message == null ? "" : message.trim().substring(0, Math.min(240, message.trim().length()));
        if (safeMessage.isEmpty()) return;
        safeMessage = "SIMULAÇÃO — " + safeMessage + " Nenhum dinheiro foi movimentado; Pix real não enviado.";
        Bitmap icon = null;
        try { icon = BitmapFactory.decodeStream(getAssets().open("picpay-notification-icon.png")); } catch (Exception ignored) { }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 23 && icon != null) builder.setSmallIcon(Icon.createWithBitmap(icon)); else builder.setSmallIcon(SMALL_ICON_ID);
        builder.setContentTitle(safeTitle).setContentText(safeMessage).setStyle(new Notification.BigTextStyle().bigText(safeMessage))
            .setCategory(Notification.CATEGORY_MESSAGE).setWhen(System.currentTimeMillis()).setShowWhen(true)
            .setAutoCancel(true).setDefaults(Notification.DEFAULT_ALL).setPriority(Notification.PRIORITY_HIGH).setTicker(safeMessage);
        if (icon != null) builder.setLargeIcon(icon);
        try { ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(nextCustomNotificationId++, builder.build()); } catch (SecurityException ignored) { }
    }

    private void postPixNotification(String amount, String recipient) {
        if (!canPostNotifications()) {
            pendingPixAmount = amount;
            pendingPixRecipient = recipient;
            requestNotificationPermissionIfNeeded();
            return;
        }
        String safeAmount = amount == null ? "R$ 0,00" : amount.substring(0, Math.min(40, amount.length()));
        String safeRecipient = recipient == null ? "destinatário" : recipient.substring(0, Math.min(100, recipient.length()));
        String content = "SIMULAÇÃO — Você fez um Pix demonstrativo de " + safeAmount + " para " + safeRecipient + ". Nenhum dinheiro foi movimentado; Pix real não enviado.";
        Bitmap large = null;
        try { large = BitmapFactory.decodeStream(getAssets().open("picpay-notification-icon.png")); } catch (Exception ignored) { }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= 23 && large != null) builder.setSmallIcon(Icon.createWithBitmap(large));
        else builder.setSmallIcon(SMALL_ICON_ID);
        builder.setContentTitle("PicPay").setContentText(content)
            .setStyle(new Notification.BigTextStyle().bigText(content)).setCategory(Notification.CATEGORY_MESSAGE)
            .setWhen(System.currentTimeMillis()).setShowWhen(true).setAutoCancel(true)
            .setDefaults(Notification.DEFAULT_ALL).setPriority(Notification.PRIORITY_HIGH)
            .setTicker(content);
        if (large != null) builder.setLargeIcon(large);
        try { ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).notify(7421, builder.build()); } catch (SecurityException ignored) { }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_NOTIFICATIONS) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingPixAmount != null) {
                    String amount = pendingPixAmount, recipient = pendingPixRecipient;
                    pendingPixAmount = null; pendingPixRecipient = null;
                    postPixNotification(amount, recipient);
                }
                if (pendingCustomMessage != null) {
                    String title = pendingCustomTitle, message = pendingCustomMessage;
                    int count = pendingCustomCount, interval = pendingCustomIntervalSeconds;
                    pendingCustomTitle = pendingCustomMessage = null;
                    startCustomNotificationSequence(title, message, count, interval);
                }
            } else {
                pendingPixAmount = pendingPixRecipient = null;
                pendingCustomTitle = pendingCustomMessage = null;
            }
            return;
        }
        if (requestCode == REQ_CAMERA && pendingWebPermission != null) {
            PermissionRequest request = pendingWebPermission; pendingWebPermission = null;
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) request.grant(request.getResources()); else request.deny();
        }
    }

    private class ShareBridge {
        @JavascriptInterface public void share(String title, String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Comprovante de Pix" : title);
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    send.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(Intent.createChooser(send, "Compartilhar comprovante"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o compartilhamento.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    private class PixNotificationBridge {
        @JavascriptInterface public void requestPermission() { runOnUiThread(() -> requestNotificationPermissionIfNeeded()); }
        @JavascriptInterface public void show(String amount, String recipient) { runOnUiThread(() -> postPixNotification(amount, recipient)); }
        @JavascriptInterface public void showCustom(String title, String message) { runOnUiThread(() -> postCustomNotification(title, message)); }
        @JavascriptInterface public void startSequence(String title, String message, int count, int intervalSeconds) { runOnUiThread(() -> startCustomNotificationSequence(title, message, count, intervalSeconds)); }
        @JavascriptInterface public void cancelSequence() { runOnUiThread(() -> { cancelCustomNotificationSequence(); pendingCustomTitle = pendingCustomMessage = null; }); }
    }
    /** Local consent/pairing controls only. Remote delivery is intentionally disabled until a backend exists. */
    private android.content.SharedPreferences securePairingPrefs() throws GeneralSecurityException, IOException {
        MasterKey key = new MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
        return EncryptedSharedPreferences.create(this, "picpay_simulation_pairing", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
    }

    private class SimulationPairingBridge {
        @JavascriptInterface public String startLanSearch() {
            runOnUiThread(() -> {
                try {
                    WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    if (wifi != null && multicastLock == null) {
                        multicastLock = wifi.createMulticastLock("picpay-visual-lan-discovery");
                        multicastLock.setReferenceCounted(false);
                        multicastLock.acquire();
                    }
                    if (localNetworkPairing == null || !localNetworkPairing.start())
                        lanPairingEvent("{\"status\":\"error\",\"message\":\"Não foi possível iniciar a busca local. Confira o Wi-Fi.\"}");
                } catch (SecurityException e) {
                    lanPairingEvent("{\"status\":\"error\",\"message\":\"O Android bloqueou a busca na rede local. Confira as permissões do app.\"}");
                }
            });
            return "searching";
        }
        @JavascriptInterface public String connectLanDevice(String id) {
            return localNetworkPairing != null && localNetworkPairing.connect(id) ? "connecting" : "not_found";
        }
        private void lanPairingEvent(String json) {
            if (webView != null) webView.evaluateJavascript("window.onLanPairingEvent && window.onLanPairingEvent(" + JSONObject.quote(json) + ")", null);
        }
        @JavascriptInterface public void initialize() {
            runOnUiThread(() -> {
                if (FirebaseApp.getApps(MainActivity.this).isEmpty()) {
                    pairingResult("backend_config_missing", "Firebase não configurado; pareamento entre aparelhos indisponível.");
                    return;
                }
                try { securePairingPrefs().edit().putBoolean("consent", true).apply(); }
                catch (Exception e) { pairingResult("secure_storage_error", "Não foi possível salvar o consentimento."); return; }
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                    if (!task.isSuccessful() || task.getResult() == null) {
                        pairingResult("token_unavailable", "Não foi possível obter o token de notificações."); return;
                    }
                    String token = task.getResult();
                    try { securePairingPrefs().edit().putString("fcm_token", token).apply(); }
                    catch (Exception e) { pairingResult("secure_storage_error", "Não foi possível guardar o token com segurança."); return; }
                    pairingResult("backend_config_missing", "Token de notificações guardado neste aparelho. Backend de pareamento indisponível; nada foi enviado.");
                });
            });
        }
        @JavascriptInterface public String createInvite() {
            String invite = java.util.UUID.randomUUID().toString();
            try { securePairingPrefs().edit().putString("invite_id", invite).putBoolean("consent", false).apply(); return invite; }
            catch (Exception e) { return "secure_storage_error"; }
        }
        @JavascriptInterface public String requestPair(String peer) { return updatePeerState(peer, "request_pending"); }
        @JavascriptInterface public String approvePair(String peer) { return updatePeerState(peer, "approved"); }
        @JavascriptInterface public String revokePair(String peer) { return updatePeerState(peer, "revoked"); }
        @JavascriptInterface public String chooseReceiver(String peer) {
            String id = peer == null ? "" : peer.trim();
            if (!id.matches("[A-Za-z0-9_-]{3,80}")) return "invalid_peer";
            try {
                android.content.SharedPreferences prefs = securePairingPrefs();
                if (!prefs.getBoolean("consent", false) || !prefs.getBoolean("pair_approved_" + id, false)) return "not_approved";
                prefs.edit().putString("selected_receiver", id).apply(); return "selected";
            } catch (Exception e) { return "secure_storage_error"; }
        }
        @JavascriptInterface public String revokeConsent() {
            try { securePairingPrefs().edit().clear().apply(); return "revoked"; }
            catch (Exception e) { return "secure_storage_error"; }
        }
        @JavascriptInterface public String sendSimulatedPix(String amount, String recipient) {
            if (amount == null || recipient == null || amount.length() > 80 || recipient.length() > 120) return "invalid_message";
            return localNetworkPairing != null && localNetworkPairing.sendPix(amount, recipient) ? "sent" : "not_connected";
        }
        private String updatePeerState(String peer, String state) {
            String id = peer == null ? "" : peer.trim();
            if (!id.matches("[A-Za-z0-9_-]{3,80}")) return "invalid_peer";
            try {
                android.content.SharedPreferences.Editor editor = securePairingPrefs().edit();
                editor.putString("pair_state_" + id, state);
                editor.putBoolean("pair_approved_" + id, "approved".equals(state));
                if ("approved".equals(state)) editor.putBoolean("consent", true);
                if ("revoked".equals(state)) {
                    editor.remove("selected_receiver").putBoolean("consent", false);
                }
                editor.apply(); return state;
            } catch (Exception e) { return "secure_storage_error"; }
        }
        private String updateLocalPairing(String value, String key) {
            try {
                android.content.SharedPreferences prefs = securePairingPrefs();
                if ("receiver".equals(key)) prefs.edit().putString("selected_receiver", value == null ? "" : value.trim()).apply();
                else if ("invite".equals(key)) prefs.edit().putBoolean("consent", false).apply();
                return "local_only";
            } catch (Exception e) { return "secure_storage_error"; }
        }
        private void pairingResult(String status, String message) {
            if (webView == null) return;
            try {
                String json = new JSONObject().put("status", status).put("message", message).toString();
                webView.evaluateJavascript("window.onNativePairingStatus && window.onNativePairingStatus(" + JSONObject.quote(json) + ")", null);
            } catch (Exception ignored) { }
        }
    }

    private static class ClipboardBridge {
        private final Context context;
        ClipboardBridge(Context context) { this.context = context; }
        @JavascriptInterface public String readText() {
            ClipboardManager manager = (ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
            if (manager == null || manager.getPrimaryClip() == null || manager.getPrimaryClip().getItemCount() == 0) return "";
            CharSequence text = manager.getPrimaryClip().getItemAt(0).coerceToText(context); return text == null ? "" : text.toString();
        }
    }
    @Override public void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= 33 && canPostNotifications()) {
            if (pendingPixAmount != null) {
                String amount = pendingPixAmount, recipient = pendingPixRecipient;
                pendingPixAmount = null; pendingPixRecipient = null;
                postPixNotification(amount, recipient);
            }
            if (pendingCustomMessage != null) {
                String title = pendingCustomTitle, message = pendingCustomMessage;
                int count = pendingCustomCount, interval = pendingCustomIntervalSeconds;
                pendingCustomTitle = pendingCustomMessage = null;
                startCustomNotificationSequence(title, message, count, interval);
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("(function(){if(window.blockmanGoHandleBack)return window.blockmanGoHandleBack();return false})()", value -> { if (!"true".equals(value)) runOnUiThread(this::finish); });
        else super.onBackPressed();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) applyImmersiveMode(); }
    @Override protected void onDestroy() { cancelCustomNotificationSequence(); if (localNetworkPairing != null) localNetworkPairing.stop(); if (multicastLock != null && multicastLock.isHeld()) multicastLock.release(); if (pendingWebPermission != null) { pendingWebPermission.deny(); pendingWebPermission = null; } if (webView != null) { webView.destroy(); webView = null; } super.onDestroy(); }
}
