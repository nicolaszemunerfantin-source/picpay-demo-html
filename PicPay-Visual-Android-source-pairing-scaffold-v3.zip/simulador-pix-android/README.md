# PicPay Visual — Android demo

This project wraps the local HTML prototype in the existing Java `com.zapia.skyblock.MainActivity`. Package/applicationId: `com.zapia.picpayvisual`; current source version: 2 (1.1), higher than the previously inspected published APK's source version. UI/assets and native fullscreen, camera, clipboard, share, and local simulation notifications are retained.

## Build

`./gradlew --no-daemon assembleDebug`

The project intentionally uses one Java Activity. The obsolete competing Kotlin Activity and Kotlin plugin were removed to avoid the previous Kotlin compilation failures.

## Simulation-only messaging status

A native pairing UI and secure token storage / FCM receiver scaffolding are present. Remote delivery is intentionally gated off: there is no Firebase project configuration (`google-services.json`), no backend for invite/request/approval/revocation, and no server-authenticated FCM sender. Pair state controls are currently local-only. JavaScript's simulated Pix callback can invoke the native remote-send gate only if consent + approved selected receiver are present; it returns `backend_unavailable` and sends nothing. Inbound FCM is accepted only for `simulation=true` and a locally approved sender ID, and every notification says SIMULAÇÃO / no money moved. Do not claim two-device end-to-end behavior until a backend and two-phone test exist.

No banking connection or real money movement is implemented. Never put Firebase service-account credentials, signing keys, or other secrets in source or assets. `skyblock-debug.keystore` must never be uploaded to the repository.

## Signing caveat

A standard Gradle debug APK is not an update-compatible replacement for the previously published signed APK unless its signing certificate matches. The private signing key is intentionally not bundled here. Confirm signer certificate and bump version against the installed APK before distribution. The source/build artifacts are not presented as an install-over update until signature verification succeeds.
