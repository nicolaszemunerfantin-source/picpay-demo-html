package com.zapia.skyblock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

/** Visible foreground keeper for an already-approved local demo pairing session. */
public final class LocalPairingService extends Service {
    static final String ACTION_START="com.zapia.picpayvisual.LAN_START";
    static final String ACTION_STOP="com.zapia.picpayvisual.LAN_STOP";
    private static final String CHANNEL="picpay_lan_service";
    private static final int ID=7310;
    private static volatile boolean running;
    public static boolean isRunning(){return running;}
    public static void start(Context context){
        Intent i=new Intent(context,LocalPairingService.class).setAction(ACTION_START);
        try{if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i);}catch(Exception ignored){}
    }
    public static void stop(Context context){try{context.startService(new Intent(context,LocalPairingService.class).setAction(ACTION_STOP));}catch(Exception ignored){}}
    @Override public void onCreate(){super.onCreate();createChannel();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"PicPay Visual — conexão entre aparelhos",NotificationManager.IMPORTANCE_LOW);c.setDescription("Mantém ativa a conexão Wi‑Fi de demonstração para receber avisos.");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&ACTION_STOP.equals(intent.getAction())){running=false;stopForeground(true);stopSelf();return START_NOT_STICKY;}
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_wifi).setContentTitle("PicPay Visual conectado").setContentText("Avisos de simulação pela rede Wi‑Fi local ativos").setContentIntent(pi).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);else startForeground(ID,n);
        running=true;return START_NOT_STICKY;
    }
    @Override public void onDestroy(){running=false;MainActivity.stopBackgroundPairing();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
